(function ($) {
    "use strict";
    
    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });

    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });
    document.getElementById("contactForm").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent submission for validation
        let isValid = true;
    
        const name = document.getElementById("name");
        const email = document.getElementById("email");
        const subject = document.getElementById("subject");
        const message = document.getElementById("message");
    
        if (name.value.trim() === "") {
            showError(name, "Name is required.");
            isValid = false;
        }
    
        if (!validateEmail(email.value)) {
            showError(email, "Enter a valid email address.");
            isValid = false;
        }
    
        if (subject.value.trim() === "") {
            showError(subject, "Subject is required.");
            isValid = false;
        }
    
        if (message.value.trim() === "") {
            showError(message, "Message cannot be empty.");
            isValid = false;
        }
    
        if (isValid) {
            this.submit(); // Submit only if validation passes
        }
    });
    
    function validateEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
    
    function showError(input, message) {
        const errorBlock = input.nextElementSibling;
        errorBlock.textContent = message;
        errorBlock.classList.add("text-danger");
    }
    

    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        center: true,
        autoplay: true,
        smartSpeed: 2000,
        dots: true,
        loop: true,
        responsive: {
            0:{
                items:1
            },
            576:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:3
            }
        }
    });
    
})(jQuery);

